package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Pages 
{
	private WebDriver driver;
  private By name=By.xpath("//input[@id=\"inputName\"]");
  private By add=By.xpath("//input[@name=\"address\"]");
  private By city=By.xpath("//input[@name=\"city\"]");
 private By state=By.xpath("//input[@name=\"state\"]");
		  private By zcode=By.xpath("//input[@name=\"zipCode\"]");
		  private By cnum=By.xpath("//input[@id=\"creditCardNumber\"]");
		  private By cmon=By.xpath("//input[@id=\"creditCardMonth\"]");
		  private By cyear=By.xpath("//input[@id=\"creditCardYear\"]");
		  private By cname=By.xpath("//input[@id=\"nameOnCard\"]");
		  private By cbox=By.xpath("//input[@name=\"rememberMe\"]");
		  private By Fbutton=By.xpath("//input[@value=\"Purchase Flight\"]");
    public Pages(WebDriver driver)
    {
    	this.driver=driver;
    	PageFactory.initElements(driver, this);
    }
    
    public void entername()
    {
    	driver.findElement(name).sendKeys("john");
 
    }
    public void enteradd()
    {
    	driver.findElement(add).sendKeys("mexico");
 
    }
    public void entercity()
    {
    	driver.findElement(city).sendKeys("mexico");
 
    }
    public void enterstate()
    {
    	driver.findElement(state).sendKeys("mexico");
 
    }
    public void enterzcode()
    {
    	driver.findElement(zcode).sendKeys("123464");
 
    }
    public void entercnum()
    {
    	driver.findElement(cnum).sendKeys("1362465245356");
 
    }
    public void entercname()
    {
    	driver.findElement(cname).sendKeys("john");
 
    }
    public void entercmonth()
    {
    	driver.findElement(cmon).sendKeys("5");
 
    }
    public void entercyear()
    {
    	driver.findElement(cyear).sendKeys("2023");
 
    }
    public void clickcbox()
    {
    	driver.findElement(cbox).click();
 
    }
    public void clickflightbutton()
    {
    	driver.findElement(Fbutton).click();
 
    }
    
}
